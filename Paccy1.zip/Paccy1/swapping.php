<?php
// define two variables
$num1 = 50;
$num2 = 10;


echo "Before : " . "num1 = " . $num1 . ", num2 = " . $num2 . "<br>";


$temp = $num1;
$num1 = $num2;
$num2 = $temp;


echo "After : " . "num1 = " . $num1 . ", num2 = " . $num2 . "<br>";
?>