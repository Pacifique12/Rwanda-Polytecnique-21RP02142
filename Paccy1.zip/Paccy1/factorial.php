<?php 
$r=15;
$factr=1;
echo "The $r factorial is ";
for ($i=$r; $i >=1 ; $i--) { 
	if ($i==1) 
		echo $i;
	else
		echo $i."*";
	$factr *=$i;
}
echo "=".$factr;
?>