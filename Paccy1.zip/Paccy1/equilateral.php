<?php
$e=5;
for($i=1;$i<$e;$i++){
	echo "<div style='margin-top:-10px;'>";
	for ($j=$i; $j <$e ; $j++) { 
		echo "&nbsp";
	}
	for ($q=0; $q <$i ; $q++) { 
		echo "*";
	}
	echo "<div>";
}

?>