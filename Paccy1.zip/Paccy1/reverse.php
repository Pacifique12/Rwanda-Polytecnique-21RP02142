<?php
$Reg="21RP02142";
$len=strlen($Reg);
echo "<h2>Registratio number: ".$Reg."<br> </h2>";
echo "<h2>Reversed Registration no: </h2>";
for ($i=$len-1; $i >=0 ; $i--) { 
	echo $Reg[$i];
}
?>