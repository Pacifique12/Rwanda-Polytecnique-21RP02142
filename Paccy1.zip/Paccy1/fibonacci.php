<?php
$a = 0; 
$b = 0;
$c = 1;
$d=15;
echo "<h1>FIBONACCI NUMBER OF ".$d." NUMBERS: </h1>"; 
echo "\n"; echo $b. ' '. $b. ' '; 
while ($a <$d ) { 
	$e = $c + $b;
	echo $e." ";
	 $b = $c;  
    $c = $e; 
    $a = $a + 1;   
}
?>